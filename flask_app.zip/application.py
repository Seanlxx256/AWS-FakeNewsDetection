from flask import Flask, request, jsonify
import pickle
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import json

# Initialize the Flask app
application = Flask(__name__)  # Beanstalk expects 'application' as the app instance name

# Load the pre-trained Naive Bayes model and vectorizer from pickle files
with open('basic_classifier.pkl', 'rb') as model_file:
    model = pickle.load(model_file)  # MultinomialNB model

with open('count_vectorizer.pkl', 'rb') as vectorizer_file:
    vectorizer = pickle.load(vectorizer_file)  # CountVectorizer


@application.route('/predict', methods=['POST'])
def predict():
    """API endpoint to receive text input and return a prediction."""
    try:
        # Parse the incoming JSON data
        data = request.get_json(force=True)
        text = data.get('text', '')

        # Validate the input
        if not isinstance(text, str) or not text.strip():
            return jsonify({"error": "Invalid input: Please provide non-empty text."}), 400

        # Transform the input text using the vectorizer
        transformed_text = vectorizer.transform([text])

        # Predict using the trained Naive Bayes model
        prediction = model.predict(transformed_text)[0]  # np.str_('REAL') or np.str_('FAKE')

        # Safely convert prediction to string
        prediction_label = str(prediction)

        # Map 'FAKE' -> 1 and 'REAL' -> 0 (or whatever logic is appropriate)
        prediction_int = 1 if prediction_label == 'FAKE' else 0

        # Return the prediction result as JSON
        return jsonify({"prediction": prediction_int}), 200

    except Exception as e:
        # Handle any unexpected errors
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500


@application.route('/', methods=['GET'])
def home():
    """Simple home route to check if the API is running."""
    return "Fake News Detection API is running!", 200

# Run the app if executed directly (useful for local testing)
if __name__ == '__main__':
    application.run(host='0.0.0.0', port=5000, debug=True)
