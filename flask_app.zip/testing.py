import requests
import time
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Define the base URL of your Flask API (verify if /predict is the right endpoint)
BASE_URL = 'http://aimodel-env.eba-dpi6ummi.us-east-2.elasticbeanstalk.com/predict'

# Test cases to check the model predictions
test_cases = [
    {"text": "this year is 2030"},  # Fake news
    {"text": "I living in sun!"},  # Fake news
    {"text": "UOFT is one of best universities in the world"},  # Real news
    {"text": "AI is growing fast"}  # Real news
]

# Prepare to collect latency data
latency_data = []

# Function for testing predictions with improved error handling
def test_prediction(text):
    try:
        # Send POST request with input text
        response = requests.post(BASE_URL, json={"text": text})

        # Print the status code and response text for debugging
        print(f"Request: {text} | Status Code: {response.status_code} | Response: {response.text}")

        # If the request is successful, return the prediction
        if response.status_code == 200:
            return response.json().get('prediction')
        else:
            return None  # Handle non-200 responses gracefully

    except Exception as e:
        print(f"Error occurred during the request: {str(e)}")
        return None

# 1. Functional/Unit Tests
print("Running Functional/Unit tests:")
for case in test_cases:
    prediction = test_prediction(case['text'])
    print(f"Input: {case['text']} => Prediction: {prediction}")

# 2. Latency/Performance Testing
print("\nRunning Latency/Performance tests:")
for case in test_cases:
    text = case['text']
    for _ in range(100):  # 100 API calls
        start_time = time.time()
        prediction = test_prediction(text)
        latency = time.time() - start_time
        latency_data.append({"text": text, "latency": latency})

# Convert latency data to DataFrame and save to CSV
df_latency = pd.DataFrame(latency_data)
csv_file = 'latency_results.csv'
df_latency.to_csv(csv_file, index=False)
print(f"\nLatency results saved to {csv_file}")

# 3. Generate Boxplot for Latency Data
plt.figure(figsize=(10, 6))
df_latency.boxplot(column='latency', by='text')
plt.title('Latency Performance Boxplot')
plt.suptitle('')
plt.xlabel('Test Case')
plt.ylabel('Latency (seconds)')
plt.grid()
plt.savefig('latency_boxplot.png')
plt.show()

# 4. Calculate and Print Average Latency per Test Case
average_latency = df_latency.groupby('text')['latency'].mean()
print("\nAverage Latency (seconds):")
print(average_latency)
